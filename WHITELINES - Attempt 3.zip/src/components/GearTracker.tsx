import { useState, useRef } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { toast } from "sonner";

type GearType = "board" | "boots" | "bindings" | "helmet" | "goggles" | "jacket" | "pants" | "gloves" | "other";
type GearStatus = "active" | "retired" | "sold";

interface GearFormData {
  name: string;
  type: GearType;
  brand: string;
  model: string;
  pricePaid?: number;
  datePurchased?: string;
  status: GearStatus;
  notes?: string;
}

export function GearTracker() {
  const [showForm, setShowForm] = useState(false);
  const [editingGear, setEditingGear] = useState<Id<"gear"> | null>(null);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const gear = useQuery(api.gear.list) || [];
  const addGear = useMutation(api.gear.add);
  const updateGear = useMutation(api.gear.update);
  const removeGear = useMutation(api.gear.remove);
  const generateUploadUrl = useMutation(api.gear.generateUploadUrl);

  const [formData, setFormData] = useState<GearFormData>({
    name: "",
    type: "board",
    brand: "",
    model: "",
    status: "active",
  });

  const gearTypes: { value: GearType; label: string }[] = [
    { value: "board", label: "Snowboard" },
    { value: "boots", label: "Boots" },
    { value: "bindings", label: "Bindings" },
    { value: "helmet", label: "Helmet" },
    { value: "goggles", label: "Goggles" },
    { value: "jacket", label: "Jacket" },
    { value: "pants", label: "Pants" },
    { value: "gloves", label: "Gloves" },
    { value: "other", label: "Other" },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      let photoId: Id<"_storage"> | undefined;

      if (selectedImage) {
        const uploadUrl = await generateUploadUrl();
        const result = await fetch(uploadUrl, {
          method: "POST",
          headers: { "Content-Type": selectedImage.type },
          body: selectedImage,
        });
        const json = await result.json();
        if (!result.ok) {
          throw new Error(`Upload failed: ${JSON.stringify(json)}`);
        }
        photoId = json.storageId;
      }

      const gearData = {
        ...formData,
        pricePaid: formData.pricePaid || undefined,
        datePurchased: formData.datePurchased || undefined,
        notes: formData.notes || undefined,
        photoId,
      };

      if (editingGear) {
        await updateGear({ id: editingGear, ...gearData });
        toast.success("Gear updated successfully");
      } else {
        await addGear(gearData);
        toast.success("Gear added successfully");
      }

      resetForm();
    } catch (error) {
      toast.error("Failed to save gear");
      console.error(error);
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      type: "board",
      brand: "",
      model: "",
      status: "active",
    });
    setSelectedImage(null);
    setShowForm(false);
    setEditingGear(null);
    if (imageInputRef.current) {
      imageInputRef.current.value = "";
    }
  };

  const handleEdit = (gearItem: any) => {
    setFormData({
      name: gearItem.name,
      type: gearItem.type,
      brand: gearItem.brand,
      model: gearItem.model,
      pricePaid: gearItem.pricePaid,
      datePurchased: gearItem.datePurchased,
      status: gearItem.status,
      notes: gearItem.notes,
    });
    setEditingGear(gearItem._id);
    setShowForm(true);
  };

  const handleDelete = async (id: Id<"gear">) => {
    if (confirm("Are you sure you want to delete this gear?")) {
      try {
        await removeGear({ id });
        toast.success("Gear deleted successfully");
      } catch (error) {
        toast.error("Failed to delete gear");
      }
    }
  };

  const getStatusClass = (status: GearStatus) => {
    switch (status) {
      case "active": return "status-active";
      case "retired": return "status-retired";
      case "sold": return "status-sold";
      default: return "status-active";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-800">Gear Locker</h2>
        <button
          onClick={() => setShowForm(true)}
          className="mountain-button-primary"
        >
          Add Gear
        </button>
      </div>

      {showForm && (
        <div className="mountain-card p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">
            {editingGear ? "Edit Gear" : "Add New Gear"}
          </h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Name *
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="mountain-input"
                placeholder="e.g., Burton Custom"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Type *
              </label>
              <select
                required
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value as GearType })}
                className="mountain-select"
              >
                {gearTypes.map((type) => (
                  <option key={type.value} value={type.value}>
                    {type.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Brand *
                </label>
                <input
                  type="text"
                  required
                  value={formData.brand}
                  onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                  className="mountain-input"
                  placeholder="e.g., Burton"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Model *
                </label>
                <input
                  type="text"
                  required
                  value={formData.model}
                  onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                  className="mountain-input"
                  placeholder="e.g., Custom X"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Price Paid
                </label>
                <input
                  type="number"
                  value={formData.pricePaid || ""}
                  onChange={(e) => setFormData({ ...formData, pricePaid: e.target.value ? Number(e.target.value) : undefined })}
                  className="mountain-input"
                  placeholder="$"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Date Purchased
                </label>
                <input
                  type="date"
                  value={formData.datePurchased || ""}
                  onChange={(e) => setFormData({ ...formData, datePurchased: e.target.value })}
                  className="mountain-input"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Status *
              </label>
              <select
                required
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as GearStatus })}
                className="mountain-select"
              >
                <option value="active">Active</option>
                <option value="retired">Retired</option>
                <option value="sold">Sold</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Photo
              </label>
              <input
                type="file"
                accept="image/*"
                ref={imageInputRef}
                onChange={(e) => setSelectedImage(e.target.files?.[0] || null)}
                className="mountain-input"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Notes
              </label>
              <textarea
                value={formData.notes || ""}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="mountain-input resize-none"
                rows={3}
                placeholder="Any additional notes..."
              />
            </div>

            <div className="flex gap-3">
              <button type="submit" className="mountain-button-primary flex-1">
                {editingGear ? "Update Gear" : "Add Gear"}
              </button>
              <button
                type="button"
                onClick={resetForm}
                className="mountain-button-secondary"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="space-y-4">
        {gear.length === 0 ? (
          <div className="mountain-card p-8 text-center">
            <p className="text-slate-500">No gear added yet. Add your first piece of equipment!</p>
          </div>
        ) : (
          gear.map((item) => (
            <div key={item._id} className="mountain-card p-4">
              <div className="flex justify-between items-start mb-3">
                <div className="flex-1">
                  <h3 className="font-semibold text-slate-800">{item.name}</h3>
                  <p className="text-sm text-slate-600">
                    {item.brand} {item.model}
                  </p>
                  <p className="text-xs text-slate-500 capitalize">
                    {item.type.replace("_", " ")}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className={getStatusClass(item.status)}>
                    {item.status}
                  </span>
                </div>
              </div>

              {item.photoUrl && (
                <img
                  src={item.photoUrl}
                  alt={item.name}
                  className="w-full h-32 object-cover rounded-lg mb-3"
                />
              )}

              <div className="flex justify-between items-center text-sm text-slate-600">
                <div>
                  {item.pricePaid && <span>${item.pricePaid}</span>}
                  {item.datePurchased && (
                    <span className="ml-2">
                      {new Date(item.datePurchased).toLocaleDateString()}
                    </span>
                  )}
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleEdit(item)}
                    className="text-sky-600 hover:text-sky-700 font-medium"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(item._id)}
                    className="text-red-600 hover:text-red-700 font-medium"
                  >
                    Delete
                  </button>
                </div>
              </div>

              {item.notes && (
                <p className="text-sm text-slate-600 mt-2 pt-2 border-t border-slate-100">
                  {item.notes}
                </p>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
