import { useState, useRef } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { toast } from "sonner";

type TrickDifficulty = "easy" | "medium" | "hard";
type TrickStatus = "learning" | "landed" | "mastered";

interface TrickFormData {
  name: string;
  difficulty: TrickDifficulty;
  status: TrickStatus;
  startDate: string;
  notes?: string;
}

export function TrickTracker() {
  const [showForm, setShowForm] = useState(false);
  const [editingTrick, setEditingTrick] = useState<Id<"tricks"> | null>(null);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [selectedVideo, setSelectedVideo] = useState<File | null>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const tricks = useQuery(api.tricks.list) || [];
  const addTrick = useMutation(api.tricks.add);
  const updateTrick = useMutation(api.tricks.update);
  const removeTrick = useMutation(api.tricks.remove);
  const generateUploadUrl = useMutation(api.tricks.generateUploadUrl);

  const [formData, setFormData] = useState<TrickFormData>({
    name: "",
    difficulty: "easy",
    status: "learning",
    startDate: new Date().toISOString().split('T')[0],
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      let photoId: Id<"_storage"> | undefined;
      let videoId: Id<"_storage"> | undefined;

      if (selectedImage) {
        const uploadUrl = await generateUploadUrl();
        const result = await fetch(uploadUrl, {
          method: "POST",
          headers: { "Content-Type": selectedImage.type },
          body: selectedImage,
        });
        const json = await result.json();
        if (!result.ok) {
          throw new Error(`Upload failed: ${JSON.stringify(json)}`);
        }
        photoId = json.storageId;
      }

      if (selectedVideo) {
        const uploadUrl = await generateUploadUrl();
        const result = await fetch(uploadUrl, {
          method: "POST",
          headers: { "Content-Type": selectedVideo.type },
          body: selectedVideo,
        });
        const json = await result.json();
        if (!result.ok) {
          throw new Error(`Upload failed: ${JSON.stringify(json)}`);
        }
        videoId = json.storageId;
      }

      const trickData = {
        ...formData,
        notes: formData.notes || undefined,
        photoId,
        videoId,
      };

      if (editingTrick) {
        await updateTrick({ id: editingTrick, ...trickData });
        toast.success("Trick updated successfully");
      } else {
        await addTrick(trickData);
        toast.success("Trick added successfully");
      }

      resetForm();
    } catch (error) {
      toast.error("Failed to save trick");
      console.error(error);
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      difficulty: "easy",
      status: "learning",
      startDate: new Date().toISOString().split('T')[0],
    });
    setSelectedImage(null);
    setSelectedVideo(null);
    setShowForm(false);
    setEditingTrick(null);
    if (imageInputRef.current) imageInputRef.current.value = "";
    if (videoInputRef.current) videoInputRef.current.value = "";
  };

  const handleEdit = (trick: any) => {
    setFormData({
      name: trick.name,
      difficulty: trick.difficulty,
      status: trick.status,
      startDate: trick.startDate,
      notes: trick.notes,
    });
    setEditingTrick(trick._id);
    setShowForm(true);
  };

  const handleDelete = async (id: Id<"tricks">) => {
    if (confirm("Are you sure you want to delete this trick?")) {
      try {
        await removeTrick({ id });
        toast.success("Trick deleted successfully");
      } catch (error) {
        toast.error("Failed to delete trick");
      }
    }
  };

  const getStatusClass = (status: TrickStatus) => {
    switch (status) {
      case "learning": return "status-learning";
      case "landed": return "status-landed";
      case "mastered": return "status-mastered";
      default: return "status-learning";
    }
  };

  const getDifficultyClass = (difficulty: TrickDifficulty) => {
    switch (difficulty) {
      case "easy": return "difficulty-easy";
      case "medium": return "difficulty-medium";
      case "hard": return "difficulty-hard";
      default: return "difficulty-easy";
    }
  };

  const getProgressStats = () => {
    const total = tricks.length;
    const mastered = tricks.filter(t => t.status === "mastered").length;
    const landed = tricks.filter(t => t.status === "landed").length;
    const learning = tricks.filter(t => t.status === "learning").length;
    
    return { total, mastered, landed, learning };
  };

  const stats = getProgressStats();

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-800">Trick Tracker</h2>
        <button
          onClick={() => setShowForm(true)}
          className="mountain-button-primary"
        >
          Add Trick
        </button>
      </div>

      {/* Progress Stats */}
      {tricks.length > 0 && (
        <div className="mountain-card p-4">
          <h3 className="font-semibold text-slate-800 mb-3">Progress</h3>
          <div className="grid grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-slate-800">{stats.total}</div>
              <div className="text-xs text-slate-600">Total</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-blue-600">{stats.learning}</div>
              <div className="text-xs text-slate-600">Learning</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-purple-600">{stats.landed}</div>
              <div className="text-xs text-slate-600">Landed</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-600">{stats.mastered}</div>
              <div className="text-xs text-slate-600">Mastered</div>
            </div>
          </div>
        </div>
      )}

      {showForm && (
        <div className="mountain-card p-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">
            {editingTrick ? "Edit Trick" : "Add New Trick"}
          </h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Trick Name *
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="mountain-input"
                placeholder="e.g., Frontside 360"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Difficulty *
                </label>
                <select
                  required
                  value={formData.difficulty}
                  onChange={(e) => setFormData({ ...formData, difficulty: e.target.value as TrickDifficulty })}
                  className="mountain-select"
                >
                  <option value="easy">Easy</option>
                  <option value="medium">Medium</option>
                  <option value="hard">Hard</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Status *
                </label>
                <select
                  required
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value as TrickStatus })}
                  className="mountain-select"
                >
                  <option value="learning">Learning</option>
                  <option value="landed">Landed</option>
                  <option value="mastered">Mastered</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Start Date *
              </label>
              <input
                type="date"
                required
                value={formData.startDate}
                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                className="mountain-input"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Photo
              </label>
              <input
                type="file"
                accept="image/*"
                ref={imageInputRef}
                onChange={(e) => setSelectedImage(e.target.files?.[0] || null)}
                className="mountain-input"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Video
              </label>
              <input
                type="file"
                accept="video/*"
                ref={videoInputRef}
                onChange={(e) => setSelectedVideo(e.target.files?.[0] || null)}
                className="mountain-input"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Notes
              </label>
              <textarea
                value={formData.notes || ""}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="mountain-input resize-none"
                rows={3}
                placeholder="Progress notes, tips, or reminders..."
              />
            </div>

            <div className="flex gap-3">
              <button type="submit" className="mountain-button-primary flex-1">
                {editingTrick ? "Update Trick" : "Add Trick"}
              </button>
              <button
                type="button"
                onClick={resetForm}
                className="mountain-button-secondary"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="space-y-4">
        {tricks.length === 0 ? (
          <div className="mountain-card p-8 text-center">
            <p className="text-slate-500">No tricks added yet. Start tracking your progress!</p>
          </div>
        ) : (
          tricks.map((trick) => (
            <div key={trick._id} className="mountain-card p-4">
              <div className="flex justify-between items-start mb-3">
                <div className="flex-1">
                  <h3 className="font-semibold text-slate-800">{trick.name}</h3>
                  <p className="text-sm text-slate-600">
                    Started: {new Date(trick.startDate).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className={getDifficultyClass(trick.difficulty)}>
                    {trick.difficulty}
                  </span>
                  <span className={getStatusClass(trick.status)}>
                    {trick.status}
                  </span>
                </div>
              </div>

              {trick.photoUrl && (
                <img
                  src={trick.photoUrl}
                  alt={trick.name}
                  className="w-full h-32 object-cover rounded-lg mb-3"
                />
              )}

              {trick.videoUrl && (
                <video
                  src={trick.videoUrl}
                  controls
                  className="w-full h-32 object-cover rounded-lg mb-3"
                />
              )}

              {trick.notes && (
                <p className="text-sm text-slate-600 mb-3 p-3 bg-slate-50 rounded-lg">
                  {trick.notes}
                </p>
              )}

              <div className="flex justify-end gap-2">
                <button
                  onClick={() => handleEdit(trick)}
                  className="text-sky-600 hover:text-sky-700 font-medium text-sm"
                >
                  Edit
                </button>
                <button
                  onClick={() => handleDelete(trick._id)}
                  className="text-red-600 hover:text-red-700 font-medium text-sm"
                >
                  Delete
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
