import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const list = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const tricks = await ctx.db
      .query("tricks")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();

    return Promise.all(
      tricks.map(async (trick) => ({
        ...trick,
        photoUrl: trick.photoId ? await ctx.storage.getUrl(trick.photoId) : null,
        videoUrl: trick.videoId ? await ctx.storage.getUrl(trick.videoId) : null,
      }))
    );
  },
});

export const add = mutation({
  args: {
    name: v.string(),
    difficulty: v.union(
      v.literal("easy"),
      v.literal("medium"),
      v.literal("hard")
    ),
    status: v.union(
      v.literal("learning"),
      v.literal("landed"),
      v.literal("mastered")
    ),
    startDate: v.string(),
    notes: v.optional(v.string()),
    photoId: v.optional(v.id("_storage")),
    videoId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    return await ctx.db.insert("tricks", {
      userId,
      ...args,
    });
  },
});

export const update = mutation({
  args: {
    id: v.id("tricks"),
    name: v.string(),
    difficulty: v.union(
      v.literal("easy"),
      v.literal("medium"),
      v.literal("hard")
    ),
    status: v.union(
      v.literal("learning"),
      v.literal("landed"),
      v.literal("mastered")
    ),
    startDate: v.string(),
    notes: v.optional(v.string()),
    photoId: v.optional(v.id("_storage")),
    videoId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const { id, ...updates } = args;
    const trick = await ctx.db.get(id);
    
    if (!trick || trick.userId !== userId) {
      throw new Error("Trick not found or not authorized");
    }

    return await ctx.db.patch(id, updates);
  },
});

export const remove = mutation({
  args: { id: v.id("tricks") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const trick = await ctx.db.get(args.id);
    if (!trick || trick.userId !== userId) {
      throw new Error("Trick not found or not authorized");
    }

    return await ctx.db.delete(args.id);
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }
    return await ctx.storage.generateUploadUrl();
  },
});

export const getGuides = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("trickGuides").collect();
  },
});
