import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const list = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const gear = await ctx.db
      .query("gear")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();

    return Promise.all(
      gear.map(async (item) => ({
        ...item,
        photoUrl: item.photoId ? await ctx.storage.getUrl(item.photoId) : null,
      }))
    );
  },
});

export const add = mutation({
  args: {
    name: v.string(),
    type: v.union(
      v.literal("board"),
      v.literal("boots"),
      v.literal("bindings"),
      v.literal("helmet"),
      v.literal("goggles"),
      v.literal("jacket"),
      v.literal("pants"),
      v.literal("gloves"),
      v.literal("other")
    ),
    brand: v.string(),
    model: v.string(),
    pricePaid: v.optional(v.number()),
    datePurchased: v.optional(v.string()),
    status: v.union(
      v.literal("active"),
      v.literal("retired"),
      v.literal("sold")
    ),
    photoId: v.optional(v.id("_storage")),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    return await ctx.db.insert("gear", {
      userId,
      ...args,
    });
  },
});

export const update = mutation({
  args: {
    id: v.id("gear"),
    name: v.string(),
    type: v.union(
      v.literal("board"),
      v.literal("boots"),
      v.literal("bindings"),
      v.literal("helmet"),
      v.literal("goggles"),
      v.literal("jacket"),
      v.literal("pants"),
      v.literal("gloves"),
      v.literal("other")
    ),
    brand: v.string(),
    model: v.string(),
    pricePaid: v.optional(v.number()),
    datePurchased: v.optional(v.string()),
    status: v.union(
      v.literal("active"),
      v.literal("retired"),
      v.literal("sold")
    ),
    photoId: v.optional(v.id("_storage")),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const { id, ...updates } = args;
    const gear = await ctx.db.get(id);
    
    if (!gear || gear.userId !== userId) {
      throw new Error("Gear not found or not authorized");
    }

    return await ctx.db.patch(id, updates);
  },
});

export const remove = mutation({
  args: { id: v.id("gear") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const gear = await ctx.db.get(args.id);
    if (!gear || gear.userId !== userId) {
      throw new Error("Gear not found or not authorized");
    }

    return await ctx.db.delete(args.id);
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }
    return await ctx.storage.generateUploadUrl();
  },
});
