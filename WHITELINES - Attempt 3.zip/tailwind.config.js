/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: "#0ea5e9", // sky-500
        "primary-hover": "#0284c7", // sky-600
        secondary: "#64748b", // slate-500
        "mountain-white": "#ffffff",
        "mountain-blue": "#e0f2fe", // sky-100
        "mountain-blue-light": "#f0f9ff", // sky-50
        "mountain-grey": "#f1f5f9", // slate-100
        "mountain-grey-dark": "#cbd5e1", // slate-300
      },
      spacing: {
        section: "2rem",
      },
      borderRadius: {
        container: "1rem",
      },
    },
  },
  plugins: [],
}
