import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  gear: defineTable({
    userId: v.id("users"),
    name: v.string(),
    type: v.union(
      v.literal("board"),
      v.literal("boots"),
      v.literal("bindings"),
      v.literal("helmet"),
      v.literal("goggles"),
      v.literal("jacket"),
      v.literal("pants"),
      v.literal("gloves"),
      v.literal("other")
    ),
    brand: v.string(),
    model: v.string(),
    pricePaid: v.optional(v.number()),
    datePurchased: v.optional(v.string()),
    status: v.union(
      v.literal("active"),
      v.literal("retired"),
      v.literal("sold")
    ),
    photoId: v.optional(v.id("_storage")),
    notes: v.optional(v.string()),
  }).index("by_user", ["userId"]),

  tricks: defineTable({
    userId: v.id("users"),
    name: v.string(),
    difficulty: v.union(
      v.literal("easy"),
      v.literal("medium"),
      v.literal("hard")
    ),
    status: v.union(
      v.literal("learning"),
      v.literal("landed"),
      v.literal("mastered")
    ),
    startDate: v.string(),
    notes: v.optional(v.string()),
    photoId: v.optional(v.id("_storage")),
    videoId: v.optional(v.id("_storage")),
  }).index("by_user", ["userId"]),

  trickGuides: defineTable({
    name: v.string(),
    difficulty: v.union(
      v.literal("easy"),
      v.literal("medium"),
      v.literal("hard")
    ),
    description: v.string(),
    steps: v.array(v.string()),
    tips: v.array(v.string()),
    prerequisites: v.array(v.string()),
  }),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
