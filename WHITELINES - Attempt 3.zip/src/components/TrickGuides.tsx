import { useState, useEffect } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

type TrickDifficulty = "easy" | "medium" | "hard";

export function TrickGuides() {
  const [selectedDifficulty, setSelectedDifficulty] = useState<TrickDifficulty | "all">("all");
  const [expandedGuide, setExpandedGuide] = useState<string | null>(null);

  const guides = useQuery(api.tricks.getGuides) || [];
  const seedGuides = useMutation(api.trickGuides.seedTrickGuides);

  useEffect(() => {
    if (guides.length === 0) {
      seedGuides();
    }
  }, [guides.length, seedGuides]);

  const filteredGuides = guides.filter(guide => 
    selectedDifficulty === "all" || guide.difficulty === selectedDifficulty
  );

  const getDifficultyClass = (difficulty: TrickDifficulty) => {
    switch (difficulty) {
      case "easy": return "difficulty-easy";
      case "medium": return "difficulty-medium";
      case "hard": return "difficulty-hard";
      default: return "difficulty-easy";
    }
  };

  const getDifficultyStats = () => {
    const easy = guides.filter(g => g.difficulty === "easy").length;
    const medium = guides.filter(g => g.difficulty === "medium").length;
    const hard = guides.filter(g => g.difficulty === "hard").length;
    return { easy, medium, hard };
  };

  const stats = getDifficultyStats();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Trick Guides</h2>
        <p className="text-slate-600">Step-by-step instructions for snowboard tricks</p>
      </div>

      {/* Stats */}
      <div className="mountain-card p-4">
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-2xl font-bold text-green-600">{stats.easy}</div>
            <div className="text-xs text-slate-600">Easy</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-yellow-600">{stats.medium}</div>
            <div className="text-xs text-slate-600">Medium</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-red-600">{stats.hard}</div>
            <div className="text-xs text-slate-600">Hard</div>
          </div>
        </div>
      </div>

      {/* Filter */}
      <div className="mountain-card p-4">
        <div className="flex gap-2 overflow-x-auto">
          <button
            onClick={() => setSelectedDifficulty("all")}
            className={`px-4 py-2 rounded-xl font-medium whitespace-nowrap transition-all ${
              selectedDifficulty === "all"
                ? "bg-sky-500 text-white"
                : "bg-slate-100 text-slate-700 hover:bg-slate-200"
            }`}
          >
            All ({guides.length})
          </button>
          <button
            onClick={() => setSelectedDifficulty("easy")}
            className={`px-4 py-2 rounded-xl font-medium whitespace-nowrap transition-all ${
              selectedDifficulty === "easy"
                ? "bg-green-500 text-white"
                : "bg-slate-100 text-slate-700 hover:bg-slate-200"
            }`}
          >
            Easy ({stats.easy})
          </button>
          <button
            onClick={() => setSelectedDifficulty("medium")}
            className={`px-4 py-2 rounded-xl font-medium whitespace-nowrap transition-all ${
              selectedDifficulty === "medium"
                ? "bg-yellow-500 text-white"
                : "bg-slate-100 text-slate-700 hover:bg-slate-200"
            }`}
          >
            Medium ({stats.medium})
          </button>
          <button
            onClick={() => setSelectedDifficulty("hard")}
            className={`px-4 py-2 rounded-xl font-medium whitespace-nowrap transition-all ${
              selectedDifficulty === "hard"
                ? "bg-red-500 text-white"
                : "bg-slate-100 text-slate-700 hover:bg-slate-200"
            }`}
          >
            Hard ({stats.hard})
          </button>
        </div>
      </div>

      {/* Guides */}
      <div className="space-y-4">
        {filteredGuides.length === 0 ? (
          <div className="mountain-card p-8 text-center">
            <p className="text-slate-500">No guides found for the selected difficulty.</p>
          </div>
        ) : (
          filteredGuides.map((guide) => (
            <div key={guide._id} className="mountain-card p-4">
              <div className="flex justify-between items-start mb-3">
                <div className="flex-1">
                  <h3 className="font-semibold text-slate-800 text-lg">{guide.name}</h3>
                  <p className="text-sm text-slate-600 mt-1">{guide.description}</p>
                </div>
                <span className={getDifficultyClass(guide.difficulty)}>
                  {guide.difficulty}
                </span>
              </div>

              {guide.prerequisites.length > 0 && (
                <div className="mb-3 p-3 bg-amber-50 rounded-lg border border-amber-200">
                  <h4 className="font-medium text-amber-800 text-sm mb-1">Prerequisites:</h4>
                  <p className="text-sm text-amber-700">
                    {guide.prerequisites.join(", ")}
                  </p>
                </div>
              )}

              <button
                onClick={() => setExpandedGuide(
                  expandedGuide === guide._id ? null : guide._id
                )}
                className="mountain-button-secondary w-full mb-3"
              >
                {expandedGuide === guide._id ? "Hide Steps" : "Show Steps"}
              </button>

              {expandedGuide === guide._id && (
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium text-slate-800 mb-2">Steps:</h4>
                    <ol className="space-y-2">
                      {guide.steps.map((step, index) => (
                        <li key={index} className="flex gap-3">
                          <span className="flex-shrink-0 w-6 h-6 bg-sky-500 text-white text-sm rounded-full flex items-center justify-center">
                            {index + 1}
                          </span>
                          <span className="text-sm text-slate-700">{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>

                  {guide.tips.length > 0 && (
                    <div>
                      <h4 className="font-medium text-slate-800 mb-2">Tips:</h4>
                      <ul className="space-y-1">
                        {guide.tips.map((tip, index) => (
                          <li key={index} className="flex gap-2">
                            <span className="text-sky-500 text-sm">•</span>
                            <span className="text-sm text-slate-700">{tip}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
