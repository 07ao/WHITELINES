import { mutation } from "./_generated/server";
import { v } from "convex/values";

export const seedTrickGuides = mutation({
  args: {},
  handler: async (ctx) => {
    const existingGuides = await ctx.db.query("trickGuides").collect();
    if (existingGuides.length > 0) {
      return "Guides already exist";
    }

    const guides = [
      {
        name: "Ollie",
        difficulty: "easy" as const,
        description: "The foundation of all snowboard tricks - lifting the board off the ground.",
        steps: [
          "Start in a comfortable riding position",
          "Bend your knees and crouch down",
          "Pop up explosively with your back leg",
          "Pull your knees up toward your chest",
          "Land with both feet"
        ],
        tips: [
          "Practice on flat ground first",
          "Focus on the timing of the pop",
          "Keep your weight centered"
        ],
        prerequisites: []
      },
      {
        name: "180",
        difficulty: "easy" as const,
        description: "A half rotation spin, landing backwards (fakie).",
        steps: [
          "Approach with moderate speed",
          "Wind up your shoulders opposite to spin direction",
          "Pop an ollie",
          "Unwind shoulders to initiate spin",
          "Spot your landing",
          "Land riding backwards"
        ],
        tips: [
          "Start with frontside 180s (easier)",
          "Use your arms to help rotation",
          "Practice riding fakie first"
        ],
        prerequisites: ["Ollie"]
      },
      {
        name: "360",
        difficulty: "medium" as const,
        description: "A full rotation spin, landing forward.",
        steps: [
          "Approach with good speed",
          "Wind up shoulders strongly",
          "Pop a high ollie",
          "Unwind with full commitment",
          "Keep spinning until you see your landing",
          "Absorb landing with bent knees"
        ],
        tips: [
          "Commit fully to the rotation",
          "Look for your landing spot",
          "Practice 180s until they're perfect first"
        ],
        prerequisites: ["Ollie", "180"]
      },
      {
        name: "Backside 180",
        difficulty: "medium" as const,
        description: "A 180 degree spin rotating toward your heel edge.",
        steps: [
          "Approach with comfortable speed",
          "Wind up shoulders toward toe edge",
          "Pop an ollie",
          "Rotate toward heel edge",
          "Spot landing over back shoulder",
          "Land in fakie position"
        ],
        tips: [
          "Harder than frontside 180",
          "Really commit to looking over your shoulder",
          "Start small and build up"
        ],
        prerequisites: ["Ollie", "180"]
      },
      {
        name: "Method",
        difficulty: "medium" as const,
        description: "A stylish grab where you arch your back and grab your heel edge.",
        steps: [
          "Approach a jump with good speed",
          "Pop off the lip",
          "Reach down and grab heel edge",
          "Arch your back and extend the grab",
          "Release grab before landing",
          "Land with knees bent"
        ],
        tips: [
          "Style is everything with this trick",
          "Hold the grab as long as possible",
          "Practice the grab motion on flat ground"
        ],
        prerequisites: ["Ollie", "Jumping"]
      },
      {
        name: "Indy Grab",
        difficulty: "easy" as const,
        description: "Grabbing the toe edge between your feet with your trailing hand.",
        steps: [
          "Approach a small jump",
          "Pop off the lip",
          "Bring knees up toward chest",
          "Reach down with back hand to grab toe edge",
          "Hold briefly",
          "Release and prepare for landing"
        ],
        tips: [
          "Start on small jumps",
          "Grab between your bindings",
          "Don't reach too early"
        ],
        prerequisites: ["Ollie"]
      },
      {
        name: "Backflip",
        difficulty: "hard" as const,
        description: "A backward somersault in the air.",
        steps: [
          "Approach with significant speed",
          "Pop hard off the lip",
          "Throw your head and shoulders back",
          "Tuck knees to chest",
          "Spot your landing",
          "Extend legs for landing"
        ],
        tips: [
          "ONLY attempt with proper instruction",
          "Start on a trampoline or foam pit",
          "Commit fully - hesitation causes injury",
          "Have a spotter when learning"
        ],
        prerequisites: ["Ollie", "360", "Comfortable with big jumps"]
      }
    ];

    for (const guide of guides) {
      await ctx.db.insert("trickGuides", guide);
    }

    return "Trick guides seeded successfully";
  },
});
