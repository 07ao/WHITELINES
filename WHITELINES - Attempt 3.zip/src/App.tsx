import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { useState } from "react";
import { GearTracker } from "./components/GearTracker";
import { TrickTracker } from "./components/TrickTracker";
import { TrickGuides } from "./components/TrickGuides";

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-blue-50">
      <Authenticated>
        <MainApp />
      </Authenticated>
      <Unauthenticated>
        <AuthScreen />
      </Unauthenticated>
      <Toaster />
    </div>
  );
}

function AuthScreen() {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-slate-800 mb-2">WhiteLines</h1>
          <p className="text-slate-600">Track your gear and master new tricks</p>
        </div>
        <div className="mountain-card p-6">
          <SignInForm />
        </div>
      </div>
    </div>
  );
}

function MainApp() {
  const [activeTab, setActiveTab] = useState<"gear" | "tricks" | "guides">("gear");
  const loggedInUser = useQuery(api.auth.loggedInUser);

  if (loggedInUser === undefined) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-sky-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-md mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-xl font-bold text-slate-800">WhiteLines</h1>
          <SignOutButton />
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-slate-200 sticky top-16 z-10">
        <div className="max-w-md mx-auto px-4 py-2">
          <div className="flex gap-1 bg-slate-100 rounded-xl p-1">
            <button
              onClick={() => setActiveTab("gear")}
              className={activeTab === "gear" ? "nav-tab-active" : "nav-tab-inactive"}
            >
              Gear
            </button>
            <button
              onClick={() => setActiveTab("tricks")}
              className={activeTab === "tricks" ? "nav-tab-active" : "nav-tab-inactive"}
            >
              Tricks
            </button>
            <button
              onClick={() => setActiveTab("guides")}
              className={activeTab === "guides" ? "nav-tab-active" : "nav-tab-inactive"}
            >
              Guides
            </button>
          </div>
        </div>
      </nav>

      {/* Content */}
      <main className="max-w-md mx-auto px-4 py-6">
        {activeTab === "gear" && <GearTracker />}
        {activeTab === "tricks" && <TrickTracker />}
        {activeTab === "guides" && <TrickGuides />}
      </main>
    </div>
  );
}
